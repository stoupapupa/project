const buyButton = document.getElementById('buy-button');
const popup = document.getElementById('popup');
const confirmButton = document.getElementById('confirm-button');

buyButton.addEventListener('click', () => {
  popup.style.display = 'block';
});

confirmButton.addEventListener('click', () => {
  const quantity = document.getElementById('quantity').value;
  // Здесь можно добавить логику для обработки покупки товара
  popup.style.display = 'none';
});