<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
    
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/reset.css">
        <link rel="stylesheet" href="css/main_style.css">
    
        <title>Document</title>
    
    
    </head>
    
    <nav>
        <a href="index.php" class="main">Sakura</a>
        
      <div class="navigation">
            <a href="kimono1.php" class="nav_option">kimono</a>
            <a href="cosplay1.php" class="nav_option">cosplay</a>
            <a href="accs1.php" class="nav_option">accessories</a>
        </div>    
        
        <a href="login_index.php" class="login">log in</a>
        
    </nav>
    
    <body>
<form class="text-center" method="post">

    <div class="login_form">
        
        <h1>Log in</h1>

        <h2 font-size: style='font-size:20px; color: black; padding-left: 90px;padding-top: 30px;'><?php include('errors.php'); ?></h2>

        <input class="enter" type="text" name="username" placeholder="Login">
        <input class="enter" type="password" name="password" placeholder="Password">
        <button class="botton_login" name="login_user" type="submit"> Log in </button>
        <a href="reg_index.php">Registration</a>
    </div>
</form>    
        


    
    </body>  

    <footer>
        <p>SAKURA</p>
        <p>@ 2023 Sakura. Все права защищены</p>
    </footer>
       
</html>