<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
    
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/reset.css">
        <link rel="stylesheet" href="css/main_style.css">
    
        <title>Document</title>
    
    
    </head>
    
    <nav>
        <a href="index.php" class="main">Sakura</a>
        
        <div class="navigation">
            <a href="kimono1.php" class="nav_option">kimono</a>
            <a href="cosplay1.php" class="nav_option">cosplay</a>
            <a href="accs1.php" class="nav_option">accessories</a>
        </div>    
        
        <a href="login_index.php" class="login">log in</a>
        
    </nav>
    
    <body>
<form class="text-center" method="post">
    <div class="reg_form">
        
        <h1>Registration</h1>
        <?php include('errors.php'); ?>
        <input class="enter" type="text" name="username" placeholder="Login" value="<?php echo $username; ?>">
        <input class="enter" type="email" name="email" placeholder="Email" value="<?php echo $username; ?>">
        <input class="enter" type="password" name="password_1" placeholder="Password">
        <input class="enter" type="password" name="password_2" placeholder="Confirmed Password ">
        <button class="botton_reg" name="reg_user" type="submit"> Registration </button>
        <button class="btn btn-primary d-block w-100" name="reg_user" type="submit" style="margin-top: 18px;">Создать</button>
        <a href="login_index.php">Log in</a>
        
    </div>
    </form>
        


    
    </body>  
    
    <footer>
        <p>SAKURA</p>
        <p>@ 2023 Sakura. Все права защищены</p>
    </footer>
    
</html>