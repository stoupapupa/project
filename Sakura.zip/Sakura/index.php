<?php include('server.php') ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
    
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/reset.css">
        <link rel="stylesheet" href="css/main_style.css">
    
        <title>Document</title>
    
    
    </head>
    
    <nav>
       
        <a href="index.php" class="main">Sakura</a>
        
       <div class="navigation">
            <a href="kimono1.php" class="nav_option">kimono</a>
            <a href="cosplay1.php" class="nav_option">cosplay</a>
            <a href="accs1.php" class="nav_option">accessories</a>
        </div>     

        <a href="login.php" class="login">log in</a>
        
    </nav>
    
    <body>
    
    <div class="welcome">
       
        <div class="welcome_info">
        
        <h1>Добро пожаловать в мир <br>Сакуры, дорогой покупатель</h1>
        <p>Насладитесь прекрасными товарами из страны восходящего солнца и не только</p>
        
        <div class="puncts">
            
            <div class="punct">
                <img src="images/servis.png" alt="галочка">
                <p>Предоставляем наш удобный сервис, чтобы вы могли комфортно выбрать любимый товар</p>          
            </div>
            
            <div class="punct">
                <img src="images/delivery.png" alt="машина">
                <p>Предоставляем наш удобный сервис, чтобы вы могли комфортно выбрать любимый товар</p>
            </div>
            
            <div class="punct">
                <img src="images/quality.png" alt="корзина">
                <p>Все наши товары оригинальные и заказываются в официальных японских магазинах.</p>
            </div>
            
            
        </div>
                
        </div>    
    </div>
    
    <div class="variants">
        
        <p>Здесь вы сможете найти традиционные кимоно, образы на любимых персонажей,а также милые аксессуары</p>
        
        <div class="photos">
        
            <img src="images/woman1.png">
            <img src="images/woman2.png">
            <img src="images/women.png">
        
        </div>
        
    </div>

    </body> 
    
    <footer>
        <p>SAKURA</p>
        <p>@ 2023 Sakura. Все права защищены</p>
    </footer> 
    
</html>
