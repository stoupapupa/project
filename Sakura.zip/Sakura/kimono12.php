<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
    
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/reset.css">
        <link rel="stylesheet" href="css/main_style.css">
    <link rel="stylesheet" href="111.css">
        <title>Document</title>
    
    
    </head>
    
    <nav>
       
        <a href="index1.php" class="main">Sakura</a>
        
        <div class="navigation">
            <a href="kimono12.php" class="nav_option">kimono</a>
            <a href="cosplay12.php" class="nav_option">cosplay</a>
            <a href="accs12.php" class="nav_option">accessories</a>
        </div>     
        
        <a href="index.php" class="login">log out</a>
        
    </nav>
    
    <body>
    
    <div class="tovar_info">
    
        <h1>Кимоно Irotomesode</h1>
        
        <img src="images/kimono1.png">
        
        
        <div class="info">
        
            
        
            <h2>Описание товара</h2>
        
            <p>Кимоно - это традиционная японская одежда, которая пользуется популярностью в множествах стран. Кимоно напоминает собой Т-образный халат. Его длина может варьироваться. Одежда закрепляется на теле поясом оби, который расположен на талии. Вместо европейских пуговиц используют ремешки и бечёвки. Характерной чертой кимоно являются рукава содэ, которые обычно намного шире толщины руки. Они имеют мешкообразную форму. Рукавное отверстие всегда меньше высоты самого рукава. </p>
        
        </div>
        
           <button class="kypit">Купить</button>


<form class="text-center" method="post">


<div id="myModal" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <p>Введите ваши данные</p>
    <input class="enter" type="text" name="username" value="Кимоно Irotomesode" readonly>
        <input class="enter" type="text" name="delivery" placeholder="Доставка">
        <input class="enter" type="text" name="mobile" placeholder="Номер мобильного">
        <button class="botton_reg" name="buy" type="submit"> Buy </button>
  </div>
</div>
<script>const modal = document.getElementById("myModal");
const btn = document.querySelector(".kypit");
const span = document.querySelector(".close");

btn.onclick = function() {
  modal.style.display = "block";
}

span.onclick = function() {
  modal.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
</form>
        
        <div class="characteristic">
        
            <h2>Характеристики товара:</h2>
        
            <p>Кимоно: льняное в японском стиле, асимметричного кроя, рукав три четверти<br>Материалы: полиэстер 95%, спандекс 5%<br>Стирка: Отбеливание запрещено, Сухая чистка, Ручная или машинная стирка, Гладить при обычной температуре ниже 150℃<br>Сделано в Японии</p>
            
        </div>
        
        <div class="garantii">
        
            <h2>Гарантии:</h2>
            
        
            <p>Вернем деньги, если товар не доставят в течение 105 дней после оплаты. У вас есть 2 недели для подачи заявки на возврат — до 119-го дня. <br>Товар не соответствует описанию? Напишите нам в течение 30 дней после получения.<br>В случае отмены деньги поступят на счет в течение 14 дней.</p>
        
        </div>
    
    </div>

    </body> 
    
    <footer>
        <p>SAKURA</p>
        <p>@ 2023 Sakura. Все права защищены</p>
    </footer> 
    
</html>